# GOMT V2.0 - Gestor de Operaciones Multitarea

**GOMT** es una aplicación de escritorio desarrollada con JavaFX que permite gestionar tareas y operaciones de forma eficiente en un entorno visual e intuitivo. Esta herramienta está pensada para usuarios que requieren controlar múltiples actividades simultáneamente, facilitando su organización y seguimiento.

## Características principales

- Interfaz gráfica moderna y amigable (FXML + CSS personalizados).
- Gestión de operaciones: creación, edición y eliminación.
- Gestión de tareas asociadas a operaciones.
- Vista centralizada del panel principal con navegación intuitiva.
- Almacenamiento local con base de datos SQLite integrada.
- Módulo "Acerca de" con información de la aplicación.

## Estructura del proyecto

GOMT_Proyecto_Interfaz_Llamativa/
├── pom.xml # Archivo de configuración Maven
├── gomt.db # Base de datos SQLite local
├── src/
│ ├── main/
│ │ ├── java/
│ │ │ └── mx/edu/uacm/gomt/
│ │ │ ├── MainApp.java # Clase principal
│ │ │ ├── ControladorUI.java # Controlador general de UI
│ │ │ ├── controlador/ # Controladores específicos (FXML)
│ │ │ ├── gestor/ # Lógica de operaciones
│ │ │ └── modelo/ # Clases Operacion, Tarea, etc.
│ │ └── resources/
│ │ ├── vistas/ # Archivos FXML (interfaz)
│ │ └── estilos/ # Hojas de estilo CSS

## Requisitos

- Java 17 o superior
- Maven 3.6+
- JavaFX SDK (configurado como dependencia en el `pom.xml`)

## Cómo ejecutar el proyecto

1. Abre el proyecto en tu IDE preferido (NetBeans, IntelliJ, Eclipse).
2. Asegúrate de que JavaFX esté correctamente configurado.
43. Ejecuta la clase principal: `MainApp.java`.

```bash
mvn clean javafx:run
