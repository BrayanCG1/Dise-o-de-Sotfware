# Documentación Técnica - GOMT V2.0

## Descripción General

**GOMT V2.0 (Gestor de Operaciones Multitarea)** es una aplicación de escritorio construida con **JavaFX** y el patrón de arquitectura **MVC**, que permite gestionar y organizar operaciones y tareas asociadas desde una interfaz gráfica estructurada.

## Arquitectura del Sistema

La aplicación está estructurada en los siguientes componentes clave:

- **Modelo (`modelo`)**: Contiene las clases que representan la lógica de negocio (e.g., `Operacion`, `Tarea`).
- **Vista (`resources/vistas`)**: Interfaces gráficas desarrolladas en FXML.
- **Controlador (`controlador`)**: Clases que gestionan la interacción entre la vista y el modelo.
- **Gestor (`gestor`)**: Lógica de gestión centralizada de operaciones.
- **Base de datos (`gomt.db`)**: Base de datos SQLite embebida.

## Diagrama de Paquetes

mx.edu.uacm.gomt
├── MainApp.java # Punto de entrada de la aplicación
├── ControladorUI.java # Coordinador de vistas
├── modelo/ # Clases de dominio
│ ├── Operacion.java
│ └── Tarea.java
├── controlador/ # Controladores FXML
│ ├── ControladorEditorOperacion.java
│ ├── ControladorEditorTarea.java
│ └── ControladorAcercaDe.java
├── gestor/ # Lógica de gestión
│ └── GestorOperaciones.java
└── resources/
├── vistas/ # Vistas FXML
├── estilos/ # Archivos CSS

## Base de Datos

La aplicación utiliza **SQLite** como sistema de persistencia. La base de datos `gomt.db` contiene al menos dos tablas principales:

- `operaciones`: almacena información de cada operación.
- `tareas`: almacena tareas asociadas a las operaciones.

El acceso se realiza mediante clases Java (no se detectó el uso de JPA/Hibernate en el proyecto actual).

## Flujo de Ejecución

1. **Inicio**: `MainApp` lanza la aplicación cargando el `panel_principal.fxml`.
2. **Navegación**: `ControladorUI` permite cambiar entre diferentes vistas.
3. **Gestión de operaciones**: `GestorOperaciones` centraliza la creación y modificación de datos.
4. **Persistencia**: Las operaciones y tareas se almacenan en `gomt.db`.

## Funcionalidades

- Crear/Editar/Borrar operaciones.
- Crear/Editar/Borrar tareas asociadas.
- Interfaz organizada por paneles.
- Tema visual "oscuro" definido por CSS (`estilo_mac_dark.css`).
- Vista “Acerca de” con detalles del proyecto.

## Dependencias

Definidas en `pom.xml`:

- `javafx-controls`
- `javafx-fxml`
- `sqlite-jdbc`

### Ejemplo de dependencia:

```xml
<dependency>
  <groupId>org.xerial</groupId>
  <artifactId>sqlite-jdbc</artifactId>
  <version>3.34.0</version>
</dependency>
