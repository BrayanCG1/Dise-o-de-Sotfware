package mx.edu.uacm.gomt.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import mx.edu.uacm.gomt.gestor.GestorOperaciones;

public class ControladorEditorTarea {

    @FXML private TextField campoNombre;
    @FXML private TextField campoDuracion;
    @FXML private TextArea campoDescripcion;
    private GestorOperaciones gestor = new GestorOperaciones();

    @FXML
    public void guardarTarea() {
        String nombre = campoNombre.getText();
        String duracionStr = campoDuracion.getText();
        String descripcion = campoDescripcion.getText();

        if (nombre != null && !nombre.isBlank() && duracionStr.matches("\\d+")) {
            int duracion = Integer.parseInt(duracionStr);
            gestor.guardarTarea(nombre, duracion, descripcion);
            System.out.println("Tarea guardada: " + nombre);
        }
        cerrar();
    }

    @FXML
    public void cancelar() {
        cerrar();
    }

    private void cerrar() {
        Stage stage = (Stage) campoNombre.getScene().getWindow();
        stage.close();
    }
}