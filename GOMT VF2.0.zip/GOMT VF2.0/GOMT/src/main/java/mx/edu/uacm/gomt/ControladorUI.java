package mx.edu.uacm.gomt;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import mx.edu.uacm.gomt.gestor.GestorOperaciones;
import mx.edu.uacm.gomt.modelo.Operacion;
import mx.edu.uacm.gomt.modelo.Tarea;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class ControladorUI {

    @FXML private TableView<Operacion> tablaOperaciones;
    @FXML private TableColumn<Operacion, String> colNombre;
    @FXML private TableColumn<Operacion, String> colEstado;

    @FXML private TableView<Tarea> tablaTareas;
    @FXML private TableColumn<Tarea, String> colTareaNombre;
    @FXML private TableColumn<Tarea, Number> colTareaDuracion;
    @FXML private TableColumn<Tarea, String> colTareaDescripcion;

    private GestorOperaciones gestor;

    @FXML
    public void initialize() {
        gestor = new GestorOperaciones();
        colNombre.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNombre()));
        colEstado.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getEstado()));
        colTareaNombre.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNombre()));
        colTareaDuracion.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getDuracion()));
        colTareaDescripcion.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDescripcion()));

        tablaOperaciones.getSelectionModel().selectedItemProperty().addListener(
            new ChangeListener<Operacion>() {
                @Override
                public void changed(ObservableValue<? extends Operacion> obs, Operacion oldVal, Operacion newVal) {
                    if (newVal != null) {
                        cargarTareas(newVal.getId());
                    }
                }
            });

        cargarOperaciones();
    }

    private void cargarOperaciones() {
        try {
            List<Operacion> lista = gestor.obtenerOperaciones();
            ObservableList<Operacion> observableList = FXCollections.observableArrayList(lista);
            tablaOperaciones.setItems(observableList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cargarTareas(int operacionId) {
        try {
            List<Tarea> tareas = gestor.obtenerTareasPorOperacion(operacionId);
            tablaTareas.setItems(FXCollections.observableArrayList(tareas));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleSalir() {
        System.exit(0);
    }

    @FXML
    public void mostrarAcercaDe() {
        abrirVentana("/vistas/acerca_de.fxml", "Acerca de GOMT");
    }

    @FXML
    public void iniciarOperacion() {
        abrirVentana("/vistas/editor_operacion.fxml", "Editor de Operación");
        cargarOperaciones();
    }

    @FXML
    public void pausarOperacion() {
        abrirVentana("/vistas/editor_tarea.fxml", "Editor de Tarea");
        Operacion op = tablaOperaciones.getSelectionModel().getSelectedItem();
        if (op != null) cargarTareas(op.getId());
    }

    @FXML
    public void finalizarOperacion() {
        
        Operacion op = tablaOperaciones.getSelectionModel().getSelectedItem();
        if (op != null) {
            gestor.finalizarOperacion(op.getId());
            cargarOperaciones();
            cargarTareas(op.getId());
        }
    
    }

    private void abrirVentana(String rutaFXML, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}