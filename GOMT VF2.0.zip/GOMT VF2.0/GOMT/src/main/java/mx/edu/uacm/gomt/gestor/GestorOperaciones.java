package mx.edu.uacm.gomt.gestor;

import mx.edu.uacm.gomt.modelo.Operacion;
import mx.edu.uacm.gomt.modelo.Tarea;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GestorOperaciones {
    private Connection conexion;

    public GestorOperaciones() {
        try {
            conexion = DriverManager.getConnection("jdbc:sqlite:gomt.db");
            crearTablas();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void crearTablas() throws SQLException {
        Statement stmt = conexion.createStatement();
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS operaciones (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, estado TEXT)");
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS tareas (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, duracion INTEGER, descripcion TEXT, operacion_id INTEGER)");
    }

    public void guardarOperacion(String nombre) {
        try {
            PreparedStatement stmt = conexion.prepareStatement("INSERT INTO operaciones (nombre, estado) VALUES (?, ?)");
            stmt.setString(1, nombre);
            stmt.setString(2, "NoIniciada");
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void guardarTarea(String nombre, int duracion, String descripcion) {
        try {
            Statement st = conexion.createStatement();
            ResultSet rs = st.executeQuery("SELECT id FROM operaciones ORDER BY id DESC LIMIT 1");
            int operacionId = rs.next() ? rs.getInt("id") : 1;

            PreparedStatement stmt = conexion.prepareStatement("INSERT INTO tareas (nombre, duracion, descripcion, operacion_id) VALUES (?, ?, ?, ?)");
            stmt.setString(1, nombre);
            stmt.setInt(2, duracion);
            stmt.setString(3, descripcion);
            stmt.setInt(4, operacionId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Operacion> obtenerOperaciones() throws SQLException {
        List<Operacion> operaciones = new ArrayList<>();
        Statement stmt = conexion.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM operaciones");
        while (rs.next()) {
            operaciones.add(new Operacion(rs.getInt("id"), rs.getString("nombre"), rs.getString("estado")));
        }
        return operaciones;
    }

    public List<Tarea> obtenerTareasPorOperacion(int operacionId) throws SQLException {
        List<Tarea> tareas = new ArrayList<>();
        PreparedStatement stmt = conexion.prepareStatement("SELECT * FROM tareas WHERE operacion_id = ?");
        stmt.setInt(1, operacionId);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            tareas.add(new Tarea(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getInt("duracion"),
                rs.getString("descripcion")
            ));
        }
        return tareas;
    }

    public void finalizarOperacion(int operacionId) {
        try {
            PreparedStatement stmt = conexion.prepareStatement("UPDATE operaciones SET estado = 'Finalizada' WHERE id = ?");
            stmt.setInt(1, operacionId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}