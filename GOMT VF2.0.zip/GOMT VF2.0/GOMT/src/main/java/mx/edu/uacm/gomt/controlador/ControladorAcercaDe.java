package mx.edu.uacm.gomt.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorAcercaDe {
    @FXML
    private Button cerrarBtn;

    @FXML
    public void cerrarVentana() {
        Stage stage = (Stage) cerrarBtn.getScene().getWindow();
        stage.close();
    }
}