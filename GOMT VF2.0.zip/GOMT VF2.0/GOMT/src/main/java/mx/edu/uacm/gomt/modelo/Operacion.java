package mx.edu.uacm.gomt.modelo;

import java.util.ArrayList;
import java.util.List;

public class Operacion {
    private int id;
    private String nombre;
    private String estado;
    private List<Tarea> tareas;

    public Operacion(int id, String nombre, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.estado = estado;
        this.tareas = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEstado() { return estado; }
    public List<Tarea> getTareas() { return tareas; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEstado(String estado) { this.estado = estado; }
    public void agregarTarea(Tarea tarea) { tareas.add(tarea); }
}