package mx.edu.uacm.gomt.modelo;

public class Tarea {
    private int id;
    private String nombre;
    private int duracion;
    private String descripcion;

    public Tarea(int id, String nombre, int duracion, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.duracion = duracion;
        this.descripcion = descripcion;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public int getDuracion() { return duracion; }
    public String getDescripcion() { return descripcion; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setDuracion(int duracion) { this.duracion = duracion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}