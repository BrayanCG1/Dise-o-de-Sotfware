package mx.edu.uacm.gomt.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import mx.edu.uacm.gomt.gestor.GestorOperaciones;

public class ControladorEditorOperacion {

    @FXML private TextField campoNombreOperacion;
    private GestorOperaciones gestor = new GestorOperaciones();

    @FXML
    public void guardarOperacion() {
        String nombre = campoNombreOperacion.getText();
        if (nombre != null && !nombre.isBlank()) {
            gestor.guardarOperacion(nombre);
            System.out.println("Operación guardada: " + nombre);
        }
        cerrar();
    }

    @FXML
    public void cancelar() {
        cerrar();
    }

    private void cerrar() {
        Stage stage = (Stage) campoNombreOperacion.getScene().getWindow();
        stage.close();
    }
}