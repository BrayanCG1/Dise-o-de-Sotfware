
package gomt.views;

import gomt.models.Operacion;
import gomt.models.Tarea;
import gomt.services.GestorOperaciones;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class NuevaTareaView {

    private VBox view;

    public NuevaTareaView(Stage stage, DashboardView dashboardView) {
        view = new VBox(15);
        view.setPadding(new Insets(20));

        Label titulo = new Label("Crear Nueva Tarea");
        titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField campoNombre = new TextField();
        campoNombre.setPromptText("Nombre de la tarea");

        ComboBox<String> comboOperacion = new ComboBox<>();
        for (Operacion op : GestorOperaciones.obtenerOperaciones()) {
            comboOperacion.getItems().add(op.getNombre());
        }

        ComboBox<String> comboEstado = new ComboBox<>();
        comboEstado.getItems().addAll("Pendiente", "En ejecución", "Completada");
        comboEstado.setValue("Pendiente");

        Button btnCrear = new Button("Crear tarea");
        btnCrear.setOnAction(e -> {
            String nombre = campoNombre.getText();
            String operacionNombre = comboOperacion.getValue();
            String estado = comboEstado.getValue();

            Tarea nuevaTarea = new Tarea(nombre);
            nuevaTarea.setEstado(estado);

            Operacion op = GestorOperaciones.buscarOperacionPorNombre(operacionNombre);
            if (op != null) {
                op.agregarTarea(nuevaTarea);
            }

            stage.setScene(new Scene(dashboardView.getView(), 900, 600));
        });

        view.getChildren().addAll(
                titulo,
                new Label("Nombre de la tarea:"), campoNombre,
                new Label("Seleccionar operación:"), comboOperacion,
                new Label("Estado:"), comboEstado,
                btnCrear
        );
    }

    public VBox getView() {
        return view;
    }
}
