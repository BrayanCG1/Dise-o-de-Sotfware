
package gomt.views;

import gomt.models.Operacion;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ModificarOperacionView {

    private VBox view;

    public ModificarOperacionView(Stage stage, Operacion operacionAnterior) {
        view = new VBox(15);
        view.setPadding(new Insets(20));

        Label titulo = new Label("Modificar Operación");
        titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField campoNombre = new TextField(operacionAnterior.getNombre());
        ComboBox<String> comboTipo = new ComboBox<>();
        comboTipo.getItems().addAll("Tipo 1", "Tipo 2", "Tipo 3");
        comboTipo.setValue(operacionAnterior.getTipo());

        ComboBox<String> comboEstado = new ComboBox<>();
        comboEstado.getItems().addAll("No iniciada", "En ejecución", "Pausada", "Finalizada");
        comboEstado.setValue(operacionAnterior.getEstado());

        TextArea campoDescripcion = new TextArea(operacionAnterior.getDescripcion());

        Button btnGuardar = new Button("Guardar");
        btnGuardar.setOnAction(e -> {
            operacionAnterior.setNombre(campoNombre.getText());
            operacionAnterior.setTipo(comboTipo.getValue());
            operacionAnterior.setEstado(comboEstado.getValue());
            operacionAnterior.setDescripcion(campoDescripcion.getText());
            stage.setScene(new Scene(new DashboardView(stage).getView(), 900, 600));
        });

        view.getChildren().addAll(
                titulo,
                new Label("Nombre de la operación:"), campoNombre,
                new Label("Tipo:"), comboTipo,
                new Label("Estado:"), comboEstado,
                new Label("Descripción:"), campoDescripcion,
                btnGuardar
        );
    }

    public VBox getView() {
        return view;
    }
}
