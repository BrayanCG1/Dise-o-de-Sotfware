
package gomt.views;

import gomt.models.Operacion;
import gomt.services.GestorOperaciones;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class DashboardView {

    private BorderPane view;

    public DashboardView(Stage stage) {
        view = new BorderPane();

        VBox menu = new VBox(10);
        menu.setPadding(new Insets(15));
        menu.setPrefWidth(200);
        Button btnTareas = new Button("Tareas");
        Button btnOperaciones = new Button("Operaciones");
        Button btnEstado = new Button("Estado");
        Button btnAcerca = new Button("Acerca de...");
        menu.getChildren().addAll(btnTareas, btnOperaciones, btnEstado, btnAcerca);
        view.setLeft(menu);

        VBox centro = new VBox(15);
        centro.setPadding(new Insets(20));

        Label titulo = new Label("Gestor de Operaciones Multitarea");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        HBox resumen = new HBox(20);
        resumen.getChildren().addAll(
                new Label("Operaciones activas: " + GestorOperaciones.obtenerOperaciones().size()),
                new Label("Tareas: mostrar tareas aquí"),
                new Label("Alertas: sin alertas")
        );

        HBox botones = new HBox(20);
        Button nuevaTarea = new Button("Crear nueva tarea");
        Button nuevaOperacion = new Button("Crear nueva operación");

        nuevaTarea.setOnAction(e -> {
            NuevaTareaView tareaView = new NuevaTareaView(stage, this);
            Scene scene = new Scene(tareaView.getView(), 500, 400);
            stage.setScene(scene);
        });

        botones.getChildren().addAll(nuevaTarea, nuevaOperacion);

        centro.getChildren().addAll(titulo, resumen, botones);
        view.setCenter(centro);
    }

    public Pane getView() {
        return view;
    }
}
