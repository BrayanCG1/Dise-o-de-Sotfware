
package gomt.services;

import gomt.models.Operacion;

import java.util.ArrayList;
import java.util.List;

public class GestorOperaciones {
    private static final List<Operacion> operaciones = new ArrayList<>();

    public static void agregarOperacion(Operacion operacion) {
        operaciones.add(operacion);
    }

    public static List<Operacion> obtenerOperaciones() {
        return operaciones;
    }

    public static Operacion buscarOperacionPorNombre(String nombre) {
        return operaciones.stream()
                .filter(op -> op.getNombre().equals(nombre))
                .findFirst()
                .orElse(null);
    }
}
