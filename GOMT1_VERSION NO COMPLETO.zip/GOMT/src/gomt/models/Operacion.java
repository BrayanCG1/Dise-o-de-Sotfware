
package gomt.models;

import java.util.ArrayList;
import java.util.List;

public class Operacion {
    private String nombre;
    private String tipo;
    private String estado;
    private String descripcion;
    private List<Tarea> tareas;

    public Operacion(String nombre) {
        this.nombre = nombre;
        this.estado = "No iniciada";
        this.tareas = new ArrayList<>();
    }

    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    public void eliminarTarea(Tarea tarea) {
        tareas.remove(tarea);
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public List<Tarea> getTareas() { return tareas; }
}
