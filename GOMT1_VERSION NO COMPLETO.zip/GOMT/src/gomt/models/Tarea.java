
package gomt.models;

public class Tarea {
    private String nombre;
    private String estado;

    public Tarea(String nombre) {
        this.nombre = nombre;
        this.estado = "Pendiente";
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
