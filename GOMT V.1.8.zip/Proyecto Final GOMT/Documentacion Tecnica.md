# Documentación Técnica del Proyecto GOMT (Gestor de Operaciones Multitarea)

## 1. Introducción

GOMT es una aplicación de escritorio desarrollada en JavaFX que permite la gestión y ejecución de operaciones abstractas, cada una compuesta por múltiples tareas. La arquitectura se basa en el patrón MVC (Modelo-Vista-Controlador), lo que garantiza una clara separación de responsabilidades.

---

## 2. Arquitectura General

La arquitectura sigue el patrón **MVC** distribuido de la siguiente manera:

- **Modelo**: `Operacion`, `Tarea`
- **Vista (FXML)**: `Dashboard.fxml`, `NuevaOperacion.fxml`, `ListarOperaciones.fxml`
- **Controlador**: `DashboardController`, `NuevaOperacionController`, `ListarOperacionesController`
- **Persistencia**: `OperacionPersistence` (maneja la lectura/escritura en JSON usando Gson)
- **Clase principal**: `GOMTApp.java`

---

## 3. Modelo

### `Operacion.java`

```java
String nombre;
String tipo;
String estado;
List<Tarea> tareas;
```

Responsabilidades:
- Representa una operación lógica con múltiples tareas.
- Contiene métodos getter/setter para manipulación en controladores.

### `Tarea.java`

```java
String nombre;
String estado;
```

Representa una tarea individual asociada a una operación.

---

## 4. Persistencia

### `OperacionPersistence.java`

Encapsula el manejo de archivos usando la librería **Gson**.

- `guardarOperaciones(List<Operacion>)`: Guarda la lista de operaciones en `operaciones.json`.
- `cargarOperaciones()`: Carga operaciones desde el archivo JSON.

```java
Type listType = new TypeToken<List<Operacion>>(){}.getType();
return gson.fromJson(reader, listType);
```

**Nota:** Usa `List<Operacion>` como estructura principal.

---

## 5. Interfaz Gráfica (FXML)

Los archivos `.fxml` definen la estructura de la interfaz gráfica.

### `Dashboard.fxml`

Vista principal con botones:
- Nueva Operación
- Listar Operaciones

### `NuevaOperacion.fxml`

Formulario para ingresar nombre, tipo y estado de la operación.

### `ListarOperaciones.fxml`

Muestra operaciones en una `TableView` (no implementa columnas aún, puede extenderse).

---

## 6. Controladores

### `DashboardController.java`

Maneja eventos de navegación. Usa `FXMLLoader` para cambiar entre vistas.

```java
stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/view/NuevaOperacion.fxml"))));
```

### `NuevaOperacionController.java`

- Captura datos desde campos de texto.
- Crea un objeto `Operacion` vacío (sin tareas aún).
- Usa `OperacionPersistence` para guardar.

```java
Operacion operacion = new Operacion(nombre, tipo, estado, new ArrayList<>());
```

### `ListarOperacionesController.java`

- Carga las operaciones desde el JSON.
- Las añade a una `TableView`.

Limitación actual: no se configuran columnas explícitas en la tabla.

---

## 7. Clase Principal

### `GOMTApp.java`

Lanza la aplicación desde `Dashboard.fxml`.

```java
FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Dashboard.fxml"));
```

---

## 8. Dependencias

- **JavaFX SDK**: Requerido para la interfaz gráfica.
- **Gson 2.8.9**: Para la serialización/deserialización de operaciones.

Agregar Gson manualmente si no se usa Maven/Gradle.

---

## 9. Consideraciones de Extensión

- Implementar una vista de edición de tareas dentro de cada operación.
- Agregar validación de formularios y mensajes de error.
- Agregar soporte a múltiples usuarios o sesiones.
- Incluir estilos CSS personalizados.

---

## 10. Recomendaciones de Ejecución

- Compilar con Java 11+.
- Verifica rutas de recursos (`resources/view/`) estén correctamente configuradas en NetBeans.
- Usa `FXMLLoader.load(getClass().getResource(...))` siempre desde el contexto de recursos.

---

## 11. Autor y Uso
-Raymundo Josef Ramirez Hernandez
-Brayan Campos Guzman
Desarrollado como base para una línea de productos personalizables en JavaFX. Se permite su modificación y extensión para proyectos derivados.