package persistence;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.Operacion;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

public class OperacionPersistence {
    private static final String FILE_NAME = "operaciones.json";

    public static void guardarOperaciones(List<Operacion> operaciones) throws IOException {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter(FILE_NAME)) {
            gson.toJson(operaciones, writer);
        }
    }

    public static List<Operacion> cargarOperaciones() throws IOException {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(FILE_NAME)) {
            Type listType = new TypeToken<List<Operacion>>(){}.getType();
            return gson.fromJson(reader, listType);
        }
    }
}