package model;

import java.util.List;

public class Operacion {
    private String nombre;
    private String tipo;
    private String estado;
    private List<Tarea> tareas;

    public Operacion(String nombre, String tipo, String estado, List<Tarea> tareas) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.estado = estado;
        this.tareas = tareas;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public List<Tarea> getTareas() { return tareas; }
    public void setTareas(List<Tarea> tareas) { this.tareas = tareas; }
}