package controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import model.Operacion;
import model.Tarea;
import persistence.OperacionPersistence;

import java.util.ArrayList;
import java.util.List;

public class NuevaOperacionController {
    @FXML private TextField nombreField;
    @FXML private TextField tipoField;
    @FXML private TextField estadoField;

    public void guardarOperacion() {
        try {
            Operacion operacion = new Operacion(
                nombreField.getText(),
                tipoField.getText(),
                estadoField.getText(),
                new ArrayList<Tarea>()
            );
            List<Operacion> operaciones = OperacionPersistence.cargarOperaciones();
            operaciones.add(operacion);
            OperacionPersistence.guardarOperaciones(operaciones);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}