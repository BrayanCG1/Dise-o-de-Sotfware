package controller;

import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import model.Operacion;
import persistence.OperacionPersistence;

import java.util.List;

public class ListarOperacionesController {
    @FXML private TableView<Operacion> operacionesTable;

    public void initialize() {
        try {
            List<Operacion> operaciones = OperacionPersistence.cargarOperaciones();
            operacionesTable.getItems().addAll(operaciones);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void volver() {
        operacionesTable.getScene().getWindow().hide();
    }
}