# GOMT - Gestor de Operaciones Multitarea

Este proyecto es una implementación en JavaFX del sistema GOMT (Gestor de Operaciones Multitarea), diseñado para gestionar operaciones abstractas compuestas por múltiples tareas.

## Estructura del Proyecto

```
GOMT_Final/
├── src/
│   ├── model/               # Clases del modelo: Operacion y Tarea
│   ├── controller/          # Controladores JavaFX para las vistas
│   ├── persistence/         # Persistencia con Gson
│   └── GOMTApp.java         # Clase principal
├── resources/
│   └── view/                # Archivos FXML de la interfaz
├── nbproject/               # Carpeta para NetBeans
├── operaciones.json         # Archivo de almacenamiento de operaciones
└── Documentacion Tecnica.md # Documentacion tecnica del proyecto final
└── README.md                # Este archivo
```

## Requisitos

- **Java 11 o superior**
- **JavaFX SDK** configurado en tu entorno
- **NetBeans** con soporte para JavaFX
- **Librería Gson** (puedes agregar el JAR manualmente)

## Configuración en NetBeans

1. Abre NetBeans.
2. Selecciona `Archivo > Abrir proyecto` y elige la carpeta `GOMT_Final`.
3. Agrega la librería **Gson** al proyecto:
   - Descarga desde: https://repo1.maven.org/maven2/com/google/code/gson/gson/2.8.9/gson-2.8.9.jar
   - Haz clic derecho en el proyecto > Propiedades > Bibliotecas > Añadir JAR/Pasta.
4. Asegúrate de que NetBeans tenga configurado el **JavaFX SDK** (Ruta a JavaFX en propiedades del proyecto).
5. Ejecuta `GOMTApp.java` como aplicación principal.

## Funcionalidad

- **Dashboard.fxml**: menú principal con botones.
- **NuevaOperacion.fxml**: formulario para crear operaciones.
- **ListarOperaciones.fxml**: muestra las operaciones existentes.

## Datos

Los datos se guardan en el archivo `operaciones.json`, utilizando la librería **Gson** para serialización.

---

Desarrollado como base para una línea de productos personalizables en JavaFX.